from setuptools import setup, find_packages

setup(
    name="metodosDeOrdenamiento",
    version="0.1",
    packages=find_packages(),
    description="Librería de métodos de ordenamiento",
    author="Jhonatan Arcila",
    author_email="arcilajhonatan@gmail.com",
    url="aun no eh puesto xd",
)
