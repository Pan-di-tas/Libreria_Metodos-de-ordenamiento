from .metodosDirectos import Directos
from .metodosAlgoritmicos import Algoritmicos
